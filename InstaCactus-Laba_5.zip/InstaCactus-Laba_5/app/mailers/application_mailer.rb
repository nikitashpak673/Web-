class ApplicationMailer < ActionMailer::Base
  default from: "'Renata Cactusik' <cactusic@hello.com>"
  layout 'mailer'
end
